import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

df = pd.read_csv("RamyaS_Uptor_Final_Project.csv")

df["Year"] = df["Year"].astype(str).str[:4].astype(int)

df["Winner"] = df["Winner"].fillna(0).astype(int)

label_encoders = {}
categorical_columns = ["Award", "Name", "Film"]
for col in categorical_columns:
    df[col] = df[col].fillna("Unknown")
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

X = df[["Year", "Ceremony", "Award", "Name", "Film"]]
y = df["Winner"]

scaler = StandardScaler()
X = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

test_accuracy = accuracy_score(y_test, y_pred)
cross_val_acc = cross_val_score(model, X_train, y_train, cv=3, scoring="accuracy").mean()
print(test_accuracy)
print(cross_val_acc)

print(classification_report(y_test, y_pred))
print(confusion_matrix(y_test, y_pred))

plt.figure(figsize=(12, 6))
sns.histplot(df[df["Winner"] == 1]["Year"], bins=30, color="green", kde=True, label="Winners")
sns.histplot(df[df["Winner"] == 0]["Year"], bins=30, color="red", kde=True, label="Non-Winners", alpha=0.5)
plt.xlabel("Year")
plt.ylabel("Count")
plt.title("Distribution of Oscar Winners Over the Years")
plt.legend()
plt.show()

importances = model.feature_importances_
feature_names = ["Year", "Ceremony", "Award", "Name", "Film"]
importance_df = pd.DataFrame({"Feature": feature_names, "Importance": importances})

plt.figure(figsize=(10, 5))
sns.barplot(data=importance_df, x="Importance", y="Feature", hue="Feature", palette="viridis", legend=False)
plt.xlabel("Importance")
plt.ylabel("Feature")
plt.title("Feature Importance in Predicting Oscar Winners")
plt.show()

